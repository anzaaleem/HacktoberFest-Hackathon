
const msgInput = document.querySelector("#message");
const nameInput = document.querySelector("#name");
const chatRoom = document.querySelector("#room");
const activity = document.querySelector(".activity");
const usersList = document.querySelector(".user-list");
const roomList = document.querySelector(".room-list");
const chatDisplay = document.querySelector(".chat-display");



document.querySelector(".form-msg").addEventListener("submit", sendMessage);

document.querySelector(".form-join").addEventListener("submit", enterRoom);

msgInput.addEventListener("keypress", () => {
  socket.emit("activity", nameInput.value);
});

io.on("message", (data) => {
  activity.textContent = "";
  const { name, text, time } = data;

  let options = {

    hour: "2-digit",
    minute: "2-digit",
    
  };
  const formattedTimeString = new Date(time).toLocaleDateString("en-US", options);

  const li = document.createElement("li");
  li.className = "post";
  if (name === nameInput.value) li.className = "post post--left";
  if (name !== nameInput.value && name !== "Admin")
    li.className = "post post--right";
  if (name !== "Admin") {
    li.innerHTML = `<div class="post__header ${
      name === nameInput.value ? "post__header--user" : "post__header--reply"
    }">
        <span class="post__header--name">${name}</span> 
        <span class="post__header--time">${formattedTimeString}</span> 
        </div>
        <div class="post__text">${text}</div>`;
  } else {
    li.innerHTML = `<div class="post__text">${text}</div>`;
  }
  document.querySelector(".chat-display").appendChild(li);

  chatDisplay.scrollTop = chatDisplay.scrollHeight;
});

let activityTimer;
socket.on("activity", (name) => {
  activity.textContent = `${name} is typing...`;


  clearTimeout(activityTimer);
  activityTimer = setTimeout(() => {
    activity.textContent = "";
  }, 3000);
});

socket.on("userList", ({ users }) => {
  showUsers(users);
});

socket.on("roomList", ({ rooms }) => {
  showRooms(rooms);
});

function showUsers(users) {
  usersList.textContent = "";
  if (users) {
    usersList.innerHTML = `<em>Users in ${chatRoom.value}:</em>`;
    users.forEach((user, i) => {
      usersList.textContent += ` ${user.name}`;
      if (users.length > 1 && i !== users.length - 1) {
        usersList.textContent += ",";
      }
    });
  }
}

function showRooms(rooms) {
  roomList.textContent = "";
  if (rooms) {
    roomList.innerHTML = "<em>Active Rooms:</em>";
    rooms.forEach((room, i) => {
      roomList.textContent += ` ${room}`;
      if (rooms.length > 1 && i !== rooms.length - 1) {
        roomList.textContent += ",";
      }
    });
  }
}

function loginAsEventManager() {
  localStorage.setItem('userRole', 'eventManager');
  showEventForm();
}

function loginAsGuest() {
  localStorage.setItem('userRole', 'guest');
  hideEventForm();
}

function showEventForm() {
  const userRole = localStorage.getItem('userRole');
  if (userRole === 'eventManager') {
      document.getElementById('eventForm').style.display = 'block';
      document.getElementById('loginForm').style.display = 'none';
  }
}

function hideEventForm() {
  document.getElementById('eventForm').style.display = 'none';
  document.getElementById('loginForm').style.display = 'none';
}


function createEvent() {
  const eventName = document.getElementById('eventName').value;
  const eventDate = document.getElementById('eventDate').value;
  if (eventName && eventDate) {
      const events = JSON.parse(localStorage.getItem('events')) || [];
      events.push({ name: eventName, date: eventDate });
      localStorage.setItem('events', JSON.stringify(events));
      displayEvents();
      alert('Event created successfully!');
  } else {
      alert('Please enter all event details.');
  }
}

function displayEvents() {
  const events = JSON.parse(localStorage.getItem('events')) || [];
  const eventList = document.getElementById('events');
  eventList.innerHTML = '';
  events.forEach(event => {
      const listItem = document.createElement('li');
      listItem.textContent = `${event.name} - ${event.date}`;
      eventList.appendChild(listItem);
  });
}

displayEvents();


